<?php
echo $_GET["sub1"];
echo $_POST["sub2"];
?>